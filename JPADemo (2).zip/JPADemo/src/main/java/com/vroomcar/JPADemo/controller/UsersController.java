package com.vroomcar.JPADemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vroomcar.JPADemo.beans.Ride;
import com.vroomcar.JPADemo.repository.UserJpaRepository;

@RestController
@RequestMapping("Rest/VroomCar")
public class UsersController {
	
	@Autowired
	UserJpaRepository rideJPARepository;
	
	//@RequestMapping(value = "/allRides", method =RequestMethod.GET)
	/*
	 * @GetMapping("/allRides") public String findAll(){
	 * 
	 * return "Hello Rest API"; //return rideJPARepository.findAll(); }
	 */
	
	@GetMapping("/allRides")
	public List<Ride> findAll(){
		
		return rideJPARepository.findAll();
	}
	
	
	  @PostMapping("/loadRide") 
	  
	  public void load(@RequestBody final Ride ride) {
	  
	  rideJPARepository.save(ride);
	  
	  //return rideJPARepository.findByName(ride.getRiderName());
	  
	  }
	 
	
}
