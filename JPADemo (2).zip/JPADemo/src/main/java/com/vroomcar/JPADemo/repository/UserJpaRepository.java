package com.vroomcar.JPADemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.vroomcar.JPADemo.beans.Ride;

@Component
public interface UserJpaRepository extends JpaRepository<Ride, Long> {
	
  // Ride findByName(String name);
	
}
